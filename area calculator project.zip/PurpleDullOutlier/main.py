#write a program to create area calculator
print("***Area Calculator***")
print("""press 1 for area of square
press 2 for area of rectangle
press 3 for area of circle
press 4 for area of triangle""")
choice = int(input("enter your choice  "))
if choice == 1:
    side = float(input("enter side of square  "))
    area = side * side
    print("area of square is",(area))
    print ("Thank you for using area calculator")
elif choice == 2:
    length = float(input("enter length of rectangle  "))
    breadth = float(input("enter breadth of rectangle  "))
    area = length * breadth
    print("area of rectangle is",(area))  
    print ("Thank you for using area calculator")
elif choice == 3 :
    radius = float(input("enter radius of circle  ")) 
    area = 3.14 * radius * radius
    print("area of circle is",(area))
    print ("Thank you for using area calculator")
elif choice == 4 :
    base = float(input("enter base of triangle  "))
    height = float(input("enter height of triangle  "))
    area = 0.5 * base * height
    print("area of triangle is",(area))
    print ("Thank you for using area calculator")